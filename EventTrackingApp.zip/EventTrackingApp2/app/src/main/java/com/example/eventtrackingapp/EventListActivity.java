package com.example.eventtrackingapp;

// Created by Steven Blathras
// This activity displays a list of saved events from the database

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity {

    ListView listView;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        listView = findViewById(R.id.eventListView);
        dbHelper = new DatabaseHelper(this);

        // Get all events from the database
        Cursor cursor = dbHelper.getAllEvents();
        ArrayList<String> eventList = new ArrayList<>();

        // Loop through and add each event to the list
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                String details = cursor.getString(cursor.getColumnIndexOrThrow("details"));

                // Format each event nicely
                eventList.add(name + " - " + date + "\n" + details);

            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Toast.makeText(this, "No events found.", Toast.LENGTH_SHORT).show();
        }

        // Display the events in the ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                eventList
        );
        listView.setAdapter(adapter);
    }
}
